#export MXNET_CUDNN_AUTOTUNE_DEFAULT=0
#export PYTHONUNBUFFERED=1
#export MXNET_ENABLE_GPU_P2P=0
#export PYTHONPATH=${PYTHONPATH}:~incubator-mxnet/python/
#MODEL_DIR=model/res50-fpn/icdar2015/final
MODEL_DIR=model/final
#mkdir -p ${TRAIN_DIR}
python2 -m rcnn.tools.demo_images_maskrcnn \
    --network resnet_fpn \
    --epoch 0 \
    --thresh 0.3 \
    --vis \
    --prefix ${MODEL_DIR} \
    --gpu 1 |& tee -a test_result.log


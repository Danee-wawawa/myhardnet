from imdb import IMDB
from cityscape import Cityscape
from icdar2015 import Icdar2015
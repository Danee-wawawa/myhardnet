export MXNET_CUDNN_AUTOTUNE_DEFAULT=0
export PYTHONUNBUFFERED=1
export MXNET_ENABLE_GPU_P2P=0
export PYTHONPATH=${PYTHONPATH}:~incubator-mxnet/python/
TRAIN_DIR=model/res50-fpn/icdar2015/
DATASET=Icdar2015
SET=train
mkdir -p ${TRAIN_DIR}
python train_alternate_mask_fpn.py \
    --network resnet_fpn \
    --dataset ${DATASET} \
    --image_set ${SET} \
    --root_path ${TRAIN_DIR} \
    --pretrained model/resnet-50 \
    --pretrained_epoch 0 \
    --prefix ${TRAIN_DIR} \
    --gpu 0 |& tee -a ${TRAIN_DIR}/trian.log

